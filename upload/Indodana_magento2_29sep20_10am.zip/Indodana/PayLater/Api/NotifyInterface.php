<?php
namespace Indodana\PayLater\Api;

interface   NotifyInterface
{
    /**
     * Undocumented function
     *
     * @return string
     */
    public function Approve();
}
