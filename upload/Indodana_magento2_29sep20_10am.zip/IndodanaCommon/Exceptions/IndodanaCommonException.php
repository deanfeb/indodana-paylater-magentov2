<?php

namespace IndodanaCommon\Exceptions;

use Exception;

class IndodanaCommonException extends Exception {
}
